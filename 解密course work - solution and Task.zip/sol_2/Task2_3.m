% get the information hiden in picture_4
clc % Clear the command window
clear % Clear workspace variables
close all % Close all figures

% Set the directory for input and output images
filepath = uigetdir('','Select the folder Task2 ');
input_dir = fullfile(filepath,'/') ;

% Open the file 'keylist.txt' and read its contents
fid = fopen('keylist.txt','r');
keylist = textscan(fid,'%s');
fclose(fid);

% Obtain the number of words in the keylist and the number of columns
num_words = length(keylist{1});
num_cols = size(keylist{1},2);

% Initialize the key matrix
keys = strings(nchoosek(num_words,3)*6,1);
k = 1;

% Generate all possible keys using a triple nested loop
for i = 1:num_words
    for j = 1:num_words
        for m = 1:num_words
            % Ensure that none of the key words repeat
            if i ~= j && i ~= m && j ~= m
                % Add the new key to the keys matrix
                keys(k) = sprintf('%s-%s-%s', keylist{1}{i}, keylist{1}{j}, keylist{1}{m});
                k = k + 1;
            end
        end
    end
end

% Set the input directory and read in the image files with a PNG extension
image_files = dir([input_dir '*.png']);

% Obtain the number of images
num_images = length(image_files);

% Set the number of words and the index for the image to be analyzed
num_words = 32;
i = 4;

% Read in the image and create a subplot for it
img = imread([input_dir image_files(i).name]);
subplot(3,floor(num_images/3)+1,i)

% Loop through all possible keys to try to find the correct one
num = nchoosek(num_words,3)*6;
for k = 1:num
    % Get the current key and extract the hidden message from the image
    key = char(keys(k));
    image = LSB_steg_extract(img,key,size(img),'logical');
    % Convert the image to uint8 and decipher it using AES encryption
    image = uint8(image);
    image = Decipher(image,key,'AES');

    % Extract the red channel of the image and check for a flag pattern
    image_R = image(:,:,1);
    flag = sum(sum(image_R(740:end,1:30)));
    disp(['Finding the code  ' num2str(k/num*100) '%'])
    if ~flag
        code = keys(k);
        disp(['the code is ' code])
        break
    end
end






