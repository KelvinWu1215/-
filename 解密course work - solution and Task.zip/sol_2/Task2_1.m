democlc
clear
close all
% Set the directory for input and output images
filepath = uigetdir('','Select the folder Task2 ');
input_dir = fullfile(filepath,'/') ;
image_files = dir([input_dir '*.png']);
% Plot LSB bitplane
figure('Name', 'LSB Bitplane')
for i = 1:length(image_files)
    % Read in the image
    img = imread([input_dir image_files(i).name]);
    img = img(:,:,1);
    subplot(3,floor(length(image_files)/3)+1,i)
    imshow(bitget(img,1), []);
    title(['LSB Bitplane ' num2str(i)], 'FontSize', 10)
end

% Plot histogram
figure('Name', 'Histogram')
for i = 1:length(image_files)
    % Read in the image
    img = imread([input_dir image_files(i).name]);

    img = img(:,:,1);
    subplot(3,floor(length(image_files)/3)+1,i)
    imhist(img);
    title(['Histogram ' num2str(i)], 'FontSize', 10)
end

% Show differences between histogram bins 2i and 2i+1
figure('Name', 'Histogram Bin Difference')
for i = 1:length(image_files)
    % Read in the image
    img = imread([input_dir image_files(i).name]);

    img=img(:,:,1);
    subplot(3,floor(length(image_files)/3)+1,i)
    hc = histc(img(:),0:255);
    bar(0:2:255, hc(2:2:end)-hc(1:2:end));

    axis tight;
    title(['Histogram Bin Difference ' num2str(i)], 'FontSize', 10)
end

% Show POV of image
for i = 1:length(image_files)
    % Read in the image
    img = imread([input_dir image_files(i).name]);
    P = POV_steganalysis(img);
    disp([image_files(i).name ' POV is ' num2str(P)])
end
