function hash_value = crypto_hash(message, hash_name)
% hash_value = crypto_hash(filename, hash_name)
% hash_value = crypto_hash(message, hash_name)
% This function invokes the javax.crypto package to calculate the hash
% value of a given message or a file.
%
% Input arguments:
% message/filename: a given message or the name of an existing file
% hash_name: name of the cryptographical hash algorithm, which can be
%         'MD2', 'MD5', 'SHA-1', 'SHA-256' (default), 'SHA-384', 'SHA-512'.
% 
% The output will be an uint8 vector.
%
% Shujun Li @ www.hooklee.com 2010

hash_value = [];

if nargin<1
    disp('At least one input agument is needed!');
    return;
end
if (ischar(message) && exist(message,'file')==2)
    fid = fopen(message);
    try
    message = fread(fid, '*uint8'); % Read the whole contents of the file.
    catch me %#ok<NASGU>
        fclose(fid);
        disp('Failed to read data from the input file!');
        return;
    end
    fclose(fid);
else
    message = uint8(message);
end
if size(message,1)<numel(message)
    message = message(:)';
end

if (~exist('hash_name','var') || ...
        ~ismember(upper(hash_name), {'MD2', 'MD5', 'SHA-1', 'SHA-256', 'SHA-384', 'SHA-512'}))
    hash_name = 'SHA-256';
end

hash_instance = java.security.MessageDigest.getInstance(hash_name);
hash_value = typecast(hash_instance.digest(message), 'uint8')';
