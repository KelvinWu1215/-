function y = num2bit(x, L, endianness)
% y = num2bit(x, L, endianness)
% This function converts an input matrix x of bitsize L into a 1-D
% bitstream y.
% The default value of L is 8 (bytes to bits).
% The endianness can be 'little' or 'big' (default).
%
% Shujun Li @ www.hooklee.com 2010

y = [];

if nargin<1
    disp('At least one input argument is needed!');
    return;
end

if ~exist('L','var')
    L = 8;
end
if ~exist('endianness','var')
    endianness = 'big';
end

if ischar(x)
    x = double(x);
end
x = x(:)';

y = zeros(L, numel(x));
if strcmpi(endianness,'little')
    indices = 1:L;
else
    indices = L:-1:1;
end
for i=indices
    y(indices(i),:) = bitget(x,i);
end
y = y(:)';
