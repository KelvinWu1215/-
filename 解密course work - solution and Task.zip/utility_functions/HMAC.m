function MAC = HMAC(message, key, HmacName)
% MAC = HMAC(message, key, HmacName)
% This function calculates the MAC of a given message for a given key and a
% specific HMAC algotithm.
% HmacName: name of the HMAC algorithm, which can be 'HmacMD5', 'HmacSHA1',
% 'HmacSHA256' (default), 'HmacSHA384', 'HmacSHA512'.
% The output is an uint8 vector.
%
% The key can be a string (i.e., a normal password), which will be hashed
% by SHA-256 to get a proper key with the correct size.
% 
% This function is realized via Java Cryptography Extension.
%
% For more details, see
% http://download.oracle.com/javase/7/docs/technotes/guides/security/StandardNames.html#Mac
% Note: which HMAC algorithms are supported depends on the version of
% JavaSE installed on your computer.
%
% Shujun Li @ www.hooklee.com 2010

MAC = [];

if nargin<2
    disp('At least the plaintext and the key should be given as arguments!');
    return;
end
if isempty(key)
    disp('The key cannot be empty!');
    return;
end

if ~exist('HmacName','var')
    HmacName = 'HmacSHA256';
end
% Check if the given ciphername is valid.
if ~ismember(upper(HmacName), {'HMACMD5', 'HMACSHA1', 'HMACSHA256', 'HMACSHA384', 'HMACSHA512'})
    HmacName = 'HmacSHA256';
end
% Set the default key size and block size.
switch(upper(HmacName))
    case 'HMACMD5'
        hash_size = 128/8;
    case 'HMACSHA1'
        hash_size = 160/8;
    case 'HMACSHA256'
        hash_size = 256/8;
    case 'HMACSHA384'
        hash_size = 384/8;
    case 'HMACSHA512'
        hash_size = 512/8;
end

% The key of an HMAC algorithm can be of any size.
if ischar(key)
    key = uint8(key);
end
if ischar(message)
    message = uint8(message);
end

Mac_Instance = javax.crypto.Mac.getInstance(HmacName);
% Set the secret key for the AES instance.
Cipher_Key = javax.crypto.spec.SecretKeySpec(key, HmacName);
Mac_Instance.init(Cipher_Key); 
MAC = typecast(Mac_Instance.doFinal(message), 'uint8')';
MAC = MAC(1:hash_size);
