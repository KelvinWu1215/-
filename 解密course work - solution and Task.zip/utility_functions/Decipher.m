function plaintext = Decipher(ciphertext, key, ciphername, mode, IV, padding)
% plaintext = Decipher(ciphertext, key, ciphername, mode, IV, paddingname)
% This function decrypts a ciphertext by a cipher (default: 'AES'), for a
% given key and a  given mode (default: 'CBC') with a given initial vector
% IV (default: 0) and a given padding method (default: NoPadding =
% ZeroPadding).
% The key can be a string (i.e., a normal password), which will be hashed
% by SHA-256 to get a proper key with the correct size.
% If the key is numeric, it must be a vector of bytes otherwise they will
% be casted to uint8.
% 
% This function is realized via Java Cryptography Extension (JavaCE).
% 
% Supported options for ciphername, mode and padding:
% ciphername: 'AES', 'AESWrap', 'ARCFOUR', 'Blowfish', 'DES', 'DESede',
%             'DESedeWrap', 'RC2', 'RC4', 'RC5'
% mode: 'ECB', 'CBC', 'PCBC', 'CFB', 'CFB8' - 'CFB128', 'OFB', 
%       'OFB8' - 'OFB128', 'CTR', 'CTS'
% padding: 'NoPadding', 'ISO10126Padding', 'OAEPPadding', 'PKCS1Padding',
%           'PKCS5Padding', 'SSL3Padding'
% For more details, see
% http://java.sun.com/javase/7/docs/technotes/guides/security/StandardNames.html#Cipher
% Note: which cipher/mode/padding method is supported depends on the
% version of JavaSE installed on your computer.
% 
% Shujun Li @ www.hooklee.com 2010-2015

plaintext = [];

if nargin<2
    disp('At least the ciphertext and the key should be given as arguments!');
    return;
end
if isempty(key)
    disp('The key cannot be empty!');
    return;
end
% Check if the ciphertext is valid.
c_size = size(ciphertext);
ciphertext = ciphertext(:)';
if (min(ciphertext)<0 || max(ciphertext)>255)
    disp('The ciphertext is not valid!');
    return;
end
ciphertext = uint8(ciphertext);
% Check if the key is valid.
% key = key(:)';
% if (min(key)<0 || max(key)>255)
%     disp('The key is not valid!');
%     return;
% end

if ~exist('ciphername','var')
    ciphername = 'AES';
end
if ~exist('mode','var')
    mode = 'CBC';
end
if ~exist('padding','var')
    padding = 'NoPadding';
end

if ~exist('IV','var')
    IV = zeros(1,16);
else
    IV = IV(:)';
    if numel(IV)<16
        IV = cat(2, IV, 16-numel(IV));
    else
        IV = IV(1:16);
    end
end
if (min(IV)<0 || max(IV)>255)
    disp('The initial vector is not valid!');
    return;
end
IV = uint8(IV);

% Check if the given ciphername is valid.
ciphername = upper(ciphername);
switch ciphername
    case {'AES', 'AESWRAP', 'ARCFOUR', 'BLOWFISH', ...
        'DES', 'DESEDE', 'DESEDEWRAP', 'RC2', 'RC4', 'RC5'}
        % do nothing
    otherwise
        ciphername = 'AES';
end
% Set the default key size and block size.
switch ciphername
    case {'AES', 'AESWRAP'}
        key_byte_size = 128/8;
        block_byte_size = 128/8;
    case {'DES', 'BLOWFISH'}
        key_byte_size = 56/8;
        block_byte_size = 64/8;
    case {'DESEDE', 'DESEDEWRAP'}
        key_byte_size = 168/8;
        block_byte_size = 64/8;
    case 'RC2'
        key_byte_size = 64/8;
        block_byte_size = 64/8;
    case {'ARCFOUR', 'RC4'} % Stream cipher
        key_byte_size = 128/8;
        block_byte_size = 8/8;
    case 'RC5'
        key_byte_size = 128/8;
        block_byte_size = 64/8;
end
% Check if the given mode of operation is valid.
switch upper(mode)
    case {'ECB', 'CBC', 'PCBC', 'CFB', 'CFB8', 'CFB16', ...
        'CFB24', 'CFB32', 'CFB40', 'CFB48', 'CFB56', 'CFB64', 'CFB72', ...
        'CFB80', 'CFB88', 'CFB96', 'CFB104', 'CFB112', 'CFB120', 'CFB128', ...
        'OFB', 'OFB8', 'OFB16', 'OFB24', 'OFB32', 'OFB40', 'OFB48', 'OFB56', ...
        'OFB64', 'OFB72', 'OFB80', 'OFB88', 'OFB96', 'OFB104', 'OFB112', ...
        'OFB120', 'OFB128', 'CTR', 'CTS'}
        % do nothing
    otherwise
        mode = 'CBC';
end
% Check if the given padding method is valid.
switch upper(padding)
    case {'NOPADDING', 'ISO10126PADDING', ...
        'OAEPPADDING', 'PKCS1PADDING', 'PKCS5PADDING', 'SSL3PADDING'}
        % do nothing
    otherwise
        padding = 'NoPadding';
end

% If the key is a string or a vector with less elements, hash it with 
% SHA-256 to get a key of correct size.
if (ischar(key) || numel(key)~=key_byte_size)
    Hash_Instance = java.security.MessageDigest.getInstance('SHA-256');
    Hash_Instance.update(uint8(key));
    key = typecast(Hash_Instance.digest, 'uint8')';
    key = key(1:key_byte_size);
    clear Hash_Instance;
else
    key = uint8(key);
end
% Pad the IV to have enough bytes if necessary.
if numel(IV)<block_byte_size
    IV = [IV zeros(1,block_byte_size-numel(IV))];
end

% Set the secret key for the AES instance.
Cipher_Key = javax.crypto.spec.SecretKeySpec(key, ciphername);
% Get an instance of the cipher engine and initialize it.
if (strcmp(ciphername, 'ARCFOUR') || strcmp(ciphername, 'RC4')) % Stream cipher
    Cipher_Instance = javax.crypto.Cipher.getInstance(ciphername);
    Cipher_Instance.init(2, Cipher_Key); % 2 = DECRYPT_MODE
else % Block cipher
    Cipher_Instance = javax.crypto.Cipher.getInstance([ciphername '/' mode '/' padding]);
    % % Initialize the AES instance for encryption.
    if strcmp(mode,'ECB')
        Cipher_Instance.init(2, Cipher_Key); % 2 = DECRYPT_MODE
    else
        Cipher_Instance.init(2, Cipher_Key, javax.crypto.spec.IvParameterSpec(IV));
    end
end
% Decrypt the ciphertext.
plaintext = typecast(Cipher_Instance.doFinal(ciphertext), 'uint8')';

% Transform the 1-D plaintext back to the same dimension as the plaintext.
plaintext = reshape(plaintext, c_size);
