function [y1, y2] = zigzagN_1d_2d(x, N)
% y = zigzagN_1d_2d(x, N)
% [y1, y2] = zigzagN_1d_2d(x, N)
% This function returns the 2-D indices of a zigzag-scanned index of a
% coefficient in an NxN block.
% The default value of N is 8.
% If no input argument is given, the function will return all 2-D
% coordinates of all 1-D coefficients following the zigzag order.
% The output y is a 1 X 2 vector showing the 2-D coordinates.
% If there are two output arguments, then the y and x coordinates will be
% given to the two output arguments.
%
% Shujun Li @ www.hooklee.com 2015

if ~exist('N','var')
    N = 8;
end
N2 = N*N;

y = zigzagN(N);

if (exist('x','var') && isnumeric(x))
    x = round(x);
    if (x>0 && x<=N2)
        y = y(x,:);
    else
        disp('The 1-D index is not valid! Return all 2-D coordinates.');
    end
else
    disp('The 1-D index is not valid! Return all 2-D coordinates.');
end

switch nargout
    case {0,1}
        y1 = y;
    otherwise
        y1 = y(:,1);
        y2 = y(:,2);
end
