function y = bit2num(x, L, endianness)
% y = bit2num(x, L, endianness)
% This function converts a 1-D bitstream x into a 1-D vector of L-bit
% integers according to the defined endianness.
% The default value of L is 8 (bits to bytes).
% The endianness can be 'little' or 'big' (default).
% When there are no enough bits in x, 0-bits will be padded at the end of
% x to make it complete.
% The output argument will be a vector of integers of 8-bit, 16-bit, 32-bit
% or 64-bit, depending on the value of L.
% The function does not support L>64.
%
% Shujun Li @ www.hooklee.com 2010

y = [];

if nargin<1
    disp('At least one input argument is needed!');
    return;
end

if ~exist('L','var')
    L = 8;
end
if L>64
    disp('The bitsize of the output integers cannot be more than 64!');
    return;
end
if ~exist('endianness','var')
    endianness = 'big';
end

x = x(:)';
x_n = numel(x);
y_n = ceil(x_n/L);
if L>32
    x = cat(2, uint64(x), zeros(1,y_n*L-x_n,'uint64'));
    y = zeros(1, y_n, 'uint64');
elseif L>16
    x = cat(2, uint32(x), zeros(1,y_n*L-x_n,'uint32'));
    y = zeros(1, y_n, 'uint32');
elseif L>8
    x = cat(2, uint16(x), zeros(1,y_n*L-x_n,'uint16'));
    y = zeros(1, y_n, 'uint16');
else
    x = cat(2, uint8(x), zeros(1,y_n*L-x_n,'uint8'));
    y = zeros(1, y_n, 'uint8');
end

if strcmpi(endianness,'little')
    indices = L:-1:1;
else
    indices = 1:L;
end
for i=indices
    % Use bit- functions because math functions are not supported for
    % uint64 variables.
    y = bitxor(bitshift(y,1), x(i:L:end));
end
