function y = var2(x)
% y = var2(x)
% Sample variance of a 2-D matrix.
%
% Shujun Li @ www.hooklee.com 2013

y = [];

if ~exist('x','var')
    disp('One input agurment is needed!');
    return;
end
if numel(size(x))>2
    disp('Input agurment is not a 2-D matrix!');
    return;
end

e = mean2(x);
if isreal(x)
    y = sum(sum((x-e).^2));
else
    y = sum(sum((real(x-e)).^2)) + 1i*sum(sum((imag(x-e)).^2));
end
y = y / max(numel(x)-1, 1);
