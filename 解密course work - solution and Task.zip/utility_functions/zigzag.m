function y = zigzag(x)
% y = zigzag(x)
% This function scans all elements in a 2-D square matrix in zigzag order
% to get a 1-D vector.
%
% Shujun Li @ www.hooklee.com 2010

y = [];

if nargin<1
    disp('A 2-D array is required as the input argument!');
    return;
end

n = size(x);

if numel(n)>2
    disp('The input should be a 2-D matrix!');
    return;
end
if n(1)~=n(2)
    disp('The input should be a square matrix!');
    return;
end
n = n(1);
n2 = n^2;

y_indices = zigzagN(n);
y = zeros(1,n2);
for i=1:n2
    y(i) = x(y_indices(i,1),y_indices(i,2));
end
