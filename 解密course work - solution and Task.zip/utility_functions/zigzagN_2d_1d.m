function y = zigzagN_2d_1d(x, N)
% y = zigzagN_2d_1d(x, N)
% This function returns the 1-D zigzag-scanned index of the 2-D coordinate
% of a coefficient in an NxN block.
% The input x should be a 1 X 2 vector showing the 2-D coordinates of a
% given coefficient.
% The default value of N is 8.
% If no input argument is given, the function will return all 1-D
% indices of all 2-D coefficients.
%
% Shujun Li @ www.hooklee.com 2015

if ~exist('N','var')
    N = 8;
end
N2 = N*N;

[~, y2] = zigzagN(N);
for x1d=1:N2
    y(x1d) = find(y2==x1d);
end

if (exist('x','var') && isnumeric(x) && numel(x)==2)
    x1d = sub2ind([N N], x(1), x(2));
    if (x1d>0 && x1d<=N2)
        y = y(x1d);
    else
        disp('The 1-D index is not valid! Return all 2-D coordinates.');
    end
else
    disp('The 1-D index is not valid! Return all 2-D coordinates.');
end
