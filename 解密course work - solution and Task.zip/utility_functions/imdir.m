function image_list = imdir(dir_name, silent_mode, warning_off)
% image_list = imdir(dir_name, silent_mode, warning_off)
% An enhanced edition of dir function for image processing purpose.
% It returns a list of image files supported by MATLAB.
% The second input argument defines if the function will show any
% interactive result (default: true).
% The third input argument tells if all warnings should be disabled
% (default: true).
%
% Copyright (C) 2010-2015 Shujun Li @ www.hooklee.com

if (~exist('dir_name','var') || isempty(dir_name)) % dir_name=''
    dir_name = pwd;
end
if ~exist('silent_mode','var')
    silent_mode = true;
end
if ~exist('warning_off','var')
    warning_off = true;
end

image_list = dir(dir_name);
if (~isempty(strfind(dir_name, '*')) || exist(dir_name,'file')==2)
    dir_name = fileparts(dir_name); % dir_name is not the folder name!
end
image_list([image_list.isdir]) = []; % Remove subfolders.
image_number = numel(image_list);
if image_number<1
    return;
else
    % Remove files which are not images.
    image_invalid_flags = false(1,image_number);
    if warning_off
        % Suppress warnings that may occur in imfinfo.
        warning_state0 = warning('off','all');
    end
    for i=1:image_number
        try
            imfinfo(fullfile(dir_name, image_list(i).name));
            if (~silent_mode)
                fprintf('File %d (%s) is an image.\n', i, image_list(i).name);
            end
        catch %#ok<CTCH>
            image_invalid_flags(i) = true;
            if (~silent_mode)
                fprintf('File %d (%s) is NOT an image.\n', i, image_list(i).name);
            end
        end
    end
    if warning_off
        % Restore the original warning state of imfinfo() function.
        warning(warning_state0);
    end
    % Remove files which are not images.
    image_list(image_invalid_flags) = [];
end
