function p = randpath(n, m, k)
% p = randpath(n, m, k)
% This function generates a random path of length m in n elements under the 
% control of a key k.
% If m is not given, a full path will be returned (m=n).
% If k is not given or empty, randperm will be used to get the random path.
%
% When a key is given, the RC4 stream cipher is used as the random source.
%
% Shujun Li @ www.hooklee.com 2011

if nargin<1
    disp('At least one input argument is needed!');
    return;
end

if (~exist('m', 'var') || ~isnumeric(m) || m>n)
    m = n;
else
    m = round(m);
end

if (~exist('k','var') || isempty(k))
    p = randperm(n,m);
else
    % Use a 64-bit word stream to guarantee the performance of the random
    % path function.
    c = Encipher(zeros(1,4*n), k, 'RC4');
    c = uint64(c);
    c = ((c(1:4:end)*256 + c(2:4:end))*256 + c(3:4:end))*256 + c(4:4:end);
    [temp, p] = sort(c); %#ok<ASGLU>
end

p = p(1:m)';
