function [y, y2] = zigzagN(N)
% [y, y2] = zigzagN(N)
% This function scans an NXN matrix to get 1-D and 2-D indices of all 
% elements in the zigzag order.
% The output y is an N^2 X 2 matrix, each row denote the coordinates of the
% i-th location in the zigzag scan.
% The output y2 is an N^2 X 1 vector representing the 1-D indices of those
% elements in an NxN square matrix.
% The default value of N is 8.
%
% Shujun Li @ www.hooklee.com 2010

if nargin<1
    N = 8;
end

N2 = N^2;

y = zeros(N2,2);
y(1,:) = [1,1];

if N==1
    y = [1 1];
    y2 = 1;
    return;
end

i = 1;
j = 2;
y(2,:) = [1,2];
y_index = 2;
while y_index<N2
    if IsValidLocation(i+1,j-1,N) % If (i+1,j-1) is correct direction.
        while IsValidLocation(i+1,j-1,N)
            i = i + 1;
            j = j - 1;
            y_index = y_index+1;
            y(y_index,:) = [i,j];
        end
    else % IsValidLocation(i-1,j+1,N) % If (i-1,j+1) is correct direction.
        while IsValidLocation(i-1,j+1,N)
            i = i - 1;
            j = j + 1;
            y_index = y_index + 1;
            y(y_index,:) = [i,j];
        end
    end
    if IsBorderLocation(i+1,j,N)
        i = i + 1;
    elseif IsBorderLocation(i,j+1,N)
        j = j + 1;
    else
        break;
    end
    y_index = y_index + 1;
    y(y_index,:) = [i,j];
end

y2 = sub2ind([N N], y(:,1), y(:,2));

function y = IsValidLocation(i, j, n)

if (i<1 || j<1 || i>n || j>n)
    y = false;
else
    y = true;
end

function y = IsBorderLocation(i, j, n)

if (i<1 || j<1 || i>n || j>n)
    y = false;
elseif (i==1 || j==1 || i==n || j==n)
    y = true;
else
    y = false;
end
