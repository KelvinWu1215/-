function y = PSNR(varargin)
% y=PSNR(x2,x1,L)
% y=PSNR(x2_1,L)
% Calculate PSNR from a difference signal x1_2 and the maximal amplitude L
% (default value: 255).
% The input signal can be a n-D matrix rather than a 1-D signal.
%
% Copyright (C) 2010 Shujun Li @ www.hooklee.com

if nargin<1
    disp('At least one argument is needed!');
    return;
end
switch nargin
    case 1
        x2_1 = double(varargin{1}(:));
        L = 255;
    case 2
        if numel(varargin{1})==numel(varargin{2})
            x2 = varargin{1};
            x1 = varargin{2};
            if (all(fix(x1(:)==x1(:))) && all(fix(x2(:)==x2(:))) && ...
                    all(x1(:)>=0) && all(x1(:))<=255 && all(x2(:)>=0) && all(x2(:)<=255))
                L = 255;
            else
                L = max(double(x1(:)));
            end
            x2_1 = double(x2(:))-double(x1(:));
        else
            x2_1 = double(varargin{1}(:));
            L = double(varargin{2}(1));
        end
    otherwise % y = PSNR(x1,x2,L)
        x2 = varargin{1};
        x1 = varargin{2};
        x2_1 = double(x2(:)) - double(x1(:));
        L = double(varargin{3}(1));
end

y = 10*log10(L*L/mean(x2_1.*x2_1));
