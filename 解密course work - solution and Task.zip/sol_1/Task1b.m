clc
clear
close all

% Set the directory for input and output images
filepath = uigetdir('','Select the folder Task1 ');
input_dir = fullfile(filepath,'/') ;
filepath_out = uigetdir('','Select the folder Sol_1 ');
output_dir = fullfile(filepath_out,'/') ;

% Initialize
Bit_compare = [];

% Get all files that start with 'image' and end with '.png' in the input directory
image_files = dir([input_dir 'image*.png']);

% Loop through all the image files and extract the least significant bit from each pixel
for i = 1:length(image_files)
    % Read in the image
    img = imread([input_dir image_files(i).name]);
    B = bitget(img(:), 1);
    Bit_compare = [Bit_compare B];
end

% Calculate the sum of the least significant bits and find the indices of the pixels whose LSB sum is 0 or 10
compare = sum(Bit_compare, 2);
index = sort([find(compare == 0); find(compare == 10)]);

% Loop through all the image files again and set the LSB of the selected pixels to 0, then save the modified image
for i = 1:length(image_files)

    % Read in the image
    img = imread([input_dir image_files(i).name]);
    img(index) = bitset(img(index), 1, 0);
    imwrite(img, [output_dir image_files(i).name(1:end-4) '-zero.png']);
end