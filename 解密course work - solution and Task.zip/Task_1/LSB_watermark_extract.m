function w = LSB_watermark_extract(s, k, w_len)
% p = LSB_watermark_extract(s, k, w_len)
% This function extracts a watermark "w" from the LSB bitplane of a 
% watermarked image "s".
% A key "k" is used to select a random path. If not given or [], the
% sequential path will be used.
% The length (in bytes) of the watermark is given by "w_len" (default: floor(numel(s)/8)),
% which is the maximum possible byte length. 
% 

% This is needed so that the output is not invalid when the function
% returns earlier.
w = [];

% Check the validity of the first input argument.
if nargin<1
    disp('At least one input argument is needed!');
    return;
end

% Check if the argument 'w_len' exists or has a valid value.
if (~exist('w_len','var') || ~isnumeric(w_len))
    w_len = floor(numel(s)/8); % No length is given, then use the maximum possible length
else
    w_len = floor(w_len);
    if numel(w_len) > 1
        w_len = prod(w_len);
    end
end
wb_number = prod(w_len)*8; % Number of bits of the watermark

if wb_number>numel(s)
    disp('The watermark size exceeds the maximum capacity of the cover!');
    return;
end

% Check if the argument 'k' exists or has a valid value.
if (~exist('k', 'var') || isempty(k))
    indices = 1:wb_number; % MATLAB sequential path
else
    indices = randpath(numel(s), wb_number, k)';
end

% Note that indices is a 1-D sequence and s is a 2-D or 3-D matrix.
% In this case, the indices represent the column-row-channel 1-D indices
% of pixels in the image.
wb = bitget(s(indices), 1);

% Change the extracted 1-D bit sequence to a 1-D uint sequence.
w = bit2num(wb, 8);

end
