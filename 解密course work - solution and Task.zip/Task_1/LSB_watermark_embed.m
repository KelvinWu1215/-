function s = LSB_watermark_embed(c, w, k)
% s = LSB_watermark_embed(c, w, k)
% This function embeds a uint8 watermark "w" in the LSB bitplane of a cover 
% image "c".
% A key "k" is used to select a random path. If not given or [], the
% sequential path will be used.
% If "k" does not exist or is empty, a sequential path will be used.

% The following assignment is to ensure that the output is not
% invalid when the function returns early.
s = [];

% Check the validity of input arguments.
if nargin<2
    error('At least two input arguments are required!');
    return;
end
if (numel(size(w)) > 2 || (size(w,1) > 1 && size(w,2) > 1))
  error('The watermark must be a 1-dimensional array.');
end

% Pre-process the watermark to be a bit sequence.
switch(class(w))
    case 'uint8'
        w = num2bit(w, 8);
    case {'int8', 'char'}
        w = num2bit(uint8(w), 8);
    case 'double'
      disp('Warning: Wrong input type (double instead of uint8)');
        w = num2bit(uint8(w), 8);
    case {'uint16', 'int16'}
      disp('Warning: Wrong input type (uint16 instead of uint8)');
      w = num2bit(w, 16);
    case {'uint32', 'int32'}
      disp('Warning: Wrong input type (uint32 instead of uint8)');
        w = num2bit(w, 32);
    case {'uint64', 'int64'}
      disp('Warning: Wrong input type (uint64 instead of uint8)');
        w = num2bit(w, 64);
    case 'logical'
      disp('Warning: Wrong input type (logical instead of uint8)');
        w = w(:)';
    otherwise
        disp('The watermark must be a sequence of uint8 integers or characters!');
        return;
end
if numel(w)>numel(c)
    error('The watermark exceeds the capacity of the cover!');
    return;
end

% Check if the last argument 'k' exists or empty.
if (~exist('k', 'var') || isempty(k))
    indices = 1:numel(w); % MATLAB sequential path
else
    indices = randpath(numel(c), numel(w), k)';
end

% Make a copy of the watermark so that higher bits are in the watermarked image.
s = c;
% Note that indices is a 1-D sequence and s is a 2-D or 3-D matrix.
% In this case, the indices represent the column-row-channel 1-D indices
% of pixels in the image.
s(indices) = bitset(s(indices), 1, w);
