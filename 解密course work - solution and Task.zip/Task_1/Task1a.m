% Initialization of function input parameters
URN = 6729641;

% Load the original image
I = imread('Task_1/original.png');

% Generate the SHA-512 hash of the string '2023'
hash = crypto_hash('2023','SHA-512')

% Embed the watermark into the image using LSB steganography
I_watermarked = LSB_watermark_embed(I, watermark, URN);

% Save the watermarked image
imwrite(I_watermarked, 'Sol_1/watermarked.png');