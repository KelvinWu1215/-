% Load two images, clean_1 and clean_2
clean_1 = imread('clean_1.png');
clean_2 = imread('clean_2.png');

% Binarize clean_2 to get plaintext
plaintext = imbinarize(clean_2);

% Embed the plaintext into clean_1 using the Least Significant Bit (LSB) algorithm to get the stego image
stego = LSB_embed(clean_1, plaintext,'secret');

% Show the stego image
figure('Name','stego image')
imshow(stego)

% Extract the hidden plaintext from the stego image and convert it to a logical array
p = LSB_extract(stego,'secret',0,'logical');

% Show the extracted plaintext in logical array form
figure('Name','extracted plaintext')
imshow(p*255)

% Embed the string 'hello world' into clean_1 using the LSB algorithm to get the stego image
stego = LSB_embed(clean_1, 'hello world','secret');

% Extract the hidden string from the stego image and convert it to text
text = LSB_extract(stego,'secret');
disp(['The plaintext is ' char(text)])
