function p = LSB_extract(s, k, p_size, p_class)
% p = LSB_extract(s, k, p_size, p_class)
% This function extracts a plaintext image "p" from the LSB bitplane of a 
% stego-image "s".
% A stego-key "k" is used to select a random path. If not given or [], the
% sequential path will be used.
% The size of the plaintext is given by "p_size" , which
% is needed since the extracted bits forms a 1-D bit sequence which may not
% match the original format of the plaintext.
% If "size" is not provided or is set to 0, the function will extract the
% plaintext until the bit marker is reached.
% If "size" is provided and non-zero, the function will extract the
% specified number of bits.
% The class of the plaintext is given by "p_class" (default: 'uint8'),
% which is needed if the plaintext has a different type e.g. strings
% ('char').
% 
% In a real-world scenario, the size and type of the plaintext are
% generally unknown so they need to be transmitted to the receiver as part
% of the hidden message as well.
% A common way of doing this is to define a message header which inform the
% receiver about the needed meta-information for the extractor.
% I did not implement this feature in this function to keep it simpler.


% This is needed so that the output is not invalid when the function
% returns earlier.
p = [];

% Check the validity of the first input argument.
if nargin<1
    disp('At least one input argument is needed!');
    return;
end

% Check if the argument 'p_size' exists or has a valid value.
% or extract the bit marker at the start of the LSB embedding
if ((~exist('p_size','var') || ~isnumeric(p_size)))||p_size==0
    % Extract the bit marker at the end of the LSB embedding
    marker_lin = bitget(s(1:32), 2)';
    marker_col = bitget(s(1:32), 1)';
    p_size = [bit2num(marker_lin,32),bit2num(marker_col,32)];
else
    p_size = floor(p_size);
    if numel(p_size)==1
        p_size = [1 p_size];
    end
end
p_number = prod(p_size); % Number of bits of the plaintext.

% Check if the argument 'p_class' exists or has a valid value.
if (~exist('p_class','var') || ~ischar(p_class))
    p_class = 'uint8';
end
switch(p_class)
    case 'logical'
        pb_number = p_number;
    case {'uint8', 'int8', 'char'}
        pb_number = p_number * 8;
    case {'uint16', 'int16'}
        pb_number = p_number * 16;
    case {'uint32', 'int32'}
        pb_number = p_number * 32;
    case {'uint64', 'int64'}
        pb_number = p_number * 64;
    otherwise
        disp('The plaintext must be a sequence of bits, integers or characters!');
        return;
end

pb=zeros(1,pb_number);


if pb_number > numel(s)*2-64
    disp('The plaintext size exceeds the maximum capacity of the cover!');
    return;
end


% Check if the argument 'k' exists or has a valid value.
if (~exist('k', 'var') || isempty(k))
    indices = 33:pb_number; % MATLAB sequential path
else
    indices = randpath(numel(s)-32, pb_number, k)'+32;
end

% Note that indices is a 1-D sequence and s is a 2-D or 3-D matrix.
% In this case, the indeices represent the column-row-channel 1-D indices
% of pixels in the image.
pb(1:2:end) = bitget(s(indices(1:floor(pb_number/2))), 1);
pb(2:2:end) = bitget(s(indices(1:ceil(pb_number/2))), 2);
% Change the extracted 1-D bit sequence to a 1-D number sequence.
p_1d = bit2num(pb, pb_number/p_number);
% % Change the extracted 1-D bit sequence to a matrix matching the size of
% the plaintext.
p = reshape(p_1d, p_size);
% If type does not match, change it.
if ~strcmp(class(p),p_class)
    p = cast(p, p_class);
end
