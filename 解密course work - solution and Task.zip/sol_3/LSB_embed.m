function s = LSB_embed(c, p, k)

% Function to embed a plaintext "p" into the two least significant bitplanes of a cover image "c" using a stego-key "k"
% The LSB embedding is used to hide the plaintext in the cover image.
% A marker indicating the number of bits embedded is added to the end of the LSB embedding.
%
% Inputs:
% c - the cover image in which the plaintext is to be hidden
% p - the plaintext to be hidden
% k - an optional stego-key used to select a random path. If not given or [], the
% sequential path will be used.
%
% Outputs:
% s - the stego image with the plaintext hidden in the two LSB bitplanes.
%
% The function performs the following operations:
% 1. Checks the validity of input arguments.
% 2. Converts the plaintext to a bit sequence based on its data type.
% 3. Embeds the bit marker at the end of the LSB embedding.
% 4. Checks if the stego-key "k" exists or is empty.
% 5. Embeds the plaintext in the cover image using the LSB embedding method.
% 6. Returns the stego image with the plaintext hidden in the two LSB bitplanes.

% Initialize the output variable s to an empty array to ensure that the output is not
% invalid when the function returns early.
s = [];

% Check the validity of input arguments.
% If the number of input arguments is less than two, print an error message and return.
if nargin<2
    disp('At least two input arguments are required!');
    return;
end

% Extract the size of the plaintext for embedding the marker at the end of the LSB embedding.
% This is done to indicate the number of bits that were embedded.
marker_lin=size(p,1);
marker_col=size(p,2);

% Pre-process the plaintext to convert it to a bit sequence based on its data type.
switch(class(p))
    % Convert uint8 data type to a bit sequence.
    case 'uint8'
        p = num2bit(p, 8);
        % Convert int8 or char data type to a bit sequence by first converting it to uint8.
    case {'int8', 'char'}
        p = num2bit(uint8(p), 8);
        % Convert double data type to uint8 and then convert it to a bit sequence.
    case 'double'
        disp('For double input, we assume they are 8-bit pixel values.');
        p = num2bit(uint8(p), 8);
        % Convert uint16 or int16 data type to a bit sequence.
    case {'uint16', 'int16'}
        p = num2bit(p, 16);
        % Convert uint32 or int32 data type to a bit sequence.
    case {'uint32', 'int32'}
        p = num2bit(p, 32);
        % Convert uint64 or int64 data type to a bit sequence.
    case {'uint64', 'int64'}
        p = num2bit(p, 64);
        % For logical data type, convert it to a 1-D sequence.
    case 'logical'
        p = p(:)';
        % If the data type of the plaintext is not supported, print an error message and return.
    otherwise
        disp('The plaintext must be a sequence of bits or integers or characters!');
        return;
end

% Check if the length of the plaintext exceeds the capacity of the cover image for embedding.
if numel(p)>numel(c)*2
    disp('The plaintext exceeds the capacity of the cover!');
    return;
end

% Embed the bit marker at the end of the LSB embedding
marker_lin = num2bit(marker_lin, 32);
marker_col=num2bit(marker_col, 32);
% If the size of the bit marker in bits plus the size of the plaintext in bits
% is greater than twice the size of the cover image, then the function will
% not proceed.
if 2*numel(marker_lin)>numel(c)*2-numel(p)
    disp('The plaintext exceeds the capacity of the cover!');
    return;
end

% Determine the indices that will be used to embed the plaintext.
% If a stego-key is not provided or if it is empty, then the MATLAB
% sequential path will be used.
if (~exist('k', 'var') || isempty(k))
    indices = 33:numel(p); % MATLAB sequential path
else
    indices = randpath(numel(c)-32, numel(p), k)'+32;
end

% Copy the cover image into the stego image, and then set the bit marker in
% the two least significant bits of the first 32 pixels.
s = c;
s(1:32)= bitset(s(1:32), 2, marker_lin);
s(1:32)= bitset(s(1:32), 1, marker_col);

% Embed the plaintext in the stego image by setting the least significant bit
% of each pixel indicated by the indices array to the corresponding bit in the
% plaintext.
% Note that indices is a 1-D sequence and s is a 2-D or 3-D matrix.
% In this case, the indices represent the column-row-channel 1-D indices
% of pixels in the image.
s(indices(1:numel(p(1:2:end)))) = bitset(s(indices(1:numel(p(1:2:end)))), 1, p(1:2:end));
s(indices(1:numel(p(1:2:end)))) = bitset(s(indices(1:numel(p(2:2:end)))), 2, p(2:2:end));
end